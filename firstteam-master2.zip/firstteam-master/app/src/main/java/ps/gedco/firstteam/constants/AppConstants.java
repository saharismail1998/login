package ps.gedco.firstteam.constants;

public class AppConstants {

    //url site api , www.example.com/api/
    //https://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=439d4b804bc8187953eb36d2a8c26a02
    public static String AppAPIUrl = "https://samples.openweathermap.org/data/2.5/";
    public static String WeatherAppid = "439d4b804bc8187953eb36d2a8c26a02";
}
