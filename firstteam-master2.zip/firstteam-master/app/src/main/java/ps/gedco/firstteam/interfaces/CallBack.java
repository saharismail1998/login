package ps.gedco.firstteam.interfaces;

import android.view.View;

public interface CallBack {
   public void onClick(View v);
   public void onClick(View v , Object o);
}

