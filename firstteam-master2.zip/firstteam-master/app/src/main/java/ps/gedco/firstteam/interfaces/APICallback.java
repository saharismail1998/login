package ps.gedco.firstteam.interfaces;

public interface APICallback {

    public void onCallBack(Object o);
}
