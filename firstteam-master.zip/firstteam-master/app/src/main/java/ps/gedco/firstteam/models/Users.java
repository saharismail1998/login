package ps.gedco.firstteam.models;

public class Users {
    public String Username = "";
    public String Password = "";
}
